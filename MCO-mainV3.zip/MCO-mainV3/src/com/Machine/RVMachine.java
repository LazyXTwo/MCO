package com.Machine;

public class RVMachine extends Machine {

}
